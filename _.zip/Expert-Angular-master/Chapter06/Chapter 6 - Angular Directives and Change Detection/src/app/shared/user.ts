export class User {
  constructor(
    public userName: string,
    public userId: number) {}
}